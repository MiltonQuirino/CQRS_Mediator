# CQRS and Mediator 
 This project is a sample of using CQRS and Mediator design pattern in Microsoft .NET Core
You can find my fully article about CQRS and Mediator with .NET Core on Medium here:
https://medium.com/@letienthanh0212/cqrs-and-mediator-in-net-core-project-c0b477eab6e9?source=friends_link&sk=8233b333d04bb32c5392f071ed5e7032
